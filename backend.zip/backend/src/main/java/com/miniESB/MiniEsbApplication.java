package com.miniESB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication

public class MiniEsbApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiniEsbApplication.class, args);
	}

}
